$(function () {
    function init() {
    }
    function renderCart() {
    }
    $('#categories').change(function () {
    });
    $('#add').click(function () {
    });
    init();
});
//# sourceMappingURL=index.js.map