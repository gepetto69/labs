declare var $;

$(function () {

  function init() {

  }

  function renderCart() {

  }

  $('#categories').change(function () {

  });


  $('#add').click(function () {

  });


  init();
});
