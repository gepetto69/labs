﻿export class Person {
    constructor(public name: string) { }
}